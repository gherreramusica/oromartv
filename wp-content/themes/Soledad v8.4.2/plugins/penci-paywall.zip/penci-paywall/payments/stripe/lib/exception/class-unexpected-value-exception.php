<?php

namespace PenciPaywall\Payments\Stripe\Lib\Exception;

class Unexpected_Value_Exception extends \UnexpectedValueException implements Exception_Interface {

}
