<?php

$options = array();

$options[] = array(
	'id'    => 'pencipodcast_general_header',
	'type'  => 'soledad-fw-header',
	'label' => esc_html__( 'General Setting', 'penci-podcast' ),
);

$options[] = array(
	'id'          => 'pencipodcast_podcast_enable_player',
	'transport'   => 'postMessage',
	'default'     => true,
	'type'        => 'soledad-fw-toggle',
	'label'       => esc_html__( 'Enable Podcast Player', 'penci-podcast' ),
	'description' => esc_html__( 'Enable this feature will show podcast player.', 'penci-podcast' ),
);

$options[] = array(
	'id'              => 'pencipodcast_podcast_global_player',
	'transport'       => 'postMessage',
	'default'         => false,
	'type'            => 'soledad-fw-toggle',
	'label'           => esc_html__( 'Enable Global Player', 'penci-podcast' ),
	'description'     => esc_html__( 'Enable this feature will show podcast player globaly.', 'penci-podcast' ),
	'active_callback' => array(
		array(
			'setting'  => 'pencipodcast_podcast_enable_player',
			'operator' => '==',
			'value'    => true,
		),
	),
);

return $options;
