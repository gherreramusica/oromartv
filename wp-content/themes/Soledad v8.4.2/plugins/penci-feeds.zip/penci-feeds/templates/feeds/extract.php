<?php if ($page) : ?>
    <?php echo $page; ?>
<?php else: ?>
    <p><?php esc_html_e('Error loading page', 'penci-feeds'); ?></p>
<?php endif; ?>