<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'body' => array('//div[@class="entry-content"]'),
            'strip' => array(),
            'test_url' => 'http://voz.vn/2015/06/06/muon-trai-nghiem-bphone-hay-den-fpt-shop/',
        )
    ),
);
