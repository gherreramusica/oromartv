<?php

namespace PicoFeed\Reader;

/**
 * SubscriptionNotFoundException Exception
 *
 * @author  Frederic Guillot
 * @package Reader
 */
class SubscriptionNotFoundException extends ReaderException
{
}
