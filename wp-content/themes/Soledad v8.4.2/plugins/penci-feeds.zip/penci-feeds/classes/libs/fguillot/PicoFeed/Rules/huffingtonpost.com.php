<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.huffingtonpost.com/2014/02/20/centscere-social-media-syracuse_n_4823848.html',
            'body' => array(
                '//article[@class="content")]',
            ),
            'strip' => array(
            )
        )
    )
);
