<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.egscomics.com/index.php?id=1690',
            'title' => '/html/head/title',
            'body' => array(
                '//img[@id="comic"]'
            )
        )
    )
);
