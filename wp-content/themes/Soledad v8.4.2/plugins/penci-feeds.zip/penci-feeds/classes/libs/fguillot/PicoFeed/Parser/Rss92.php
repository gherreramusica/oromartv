<?php

namespace PicoFeed\Parser;

/**
 * RSS 0.92 Parser
 *
 * @author  Frederic Guillot
 * @package Parser
 */
class Rss92 extends Rss20
{
}
