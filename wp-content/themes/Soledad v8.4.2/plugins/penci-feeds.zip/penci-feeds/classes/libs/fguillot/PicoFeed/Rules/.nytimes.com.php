<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.nytimes.com/2011/05/15/world/middleeast/15prince.html',
            'body' => array(
                '//div[@class="articleBody"]',
            ),
        )
    )
);
