<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.phoronix.com/scan.php?page=article&item=amazon_ec2_bare&num=1',
            'body' => array(
                '//div[@class="KonaBody"]',
            ),
            'strip' => array()
        )
    )
);
