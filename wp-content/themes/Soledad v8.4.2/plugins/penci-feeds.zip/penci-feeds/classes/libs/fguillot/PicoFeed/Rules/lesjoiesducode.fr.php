<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://lesjoiesducode.fr/post/75576211207/quand-lappli-ne-fonctionne-plus-sans-aucune-raison',
            'body' => array(
                '//div[@class="blog-post-content"]',
            ),
            'strip' => array(
            )
        )
    )
);
