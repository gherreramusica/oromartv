<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.mac4ever.com/actu/87392_video-quand-steve-jobs-et-bill-gates-jouaient-au-bachelor-avec-le-mac',
            'body' => array(
                '//div[contains(@class, "news-news-content")]',
            ),
            'strip' => array(
            ),
        )
    )
);