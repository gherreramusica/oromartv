<?php

namespace PicoFeed\Client;

/**
 * MaxRedirectException Exception
 *
 * @author  Frederic Guillot
 * @package Client
 */
class MaxRedirectException extends ClientException
{
}
