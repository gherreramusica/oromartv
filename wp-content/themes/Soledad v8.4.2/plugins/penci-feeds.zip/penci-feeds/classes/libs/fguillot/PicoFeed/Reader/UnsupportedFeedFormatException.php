<?php

namespace PicoFeed\Reader;

/**
 * UnsupportedFeedFormatException Exception
 *
 * @author  Frederic Guillot
 * @package Reader
 */
class UnsupportedFeedFormatException extends ReaderException
{
}