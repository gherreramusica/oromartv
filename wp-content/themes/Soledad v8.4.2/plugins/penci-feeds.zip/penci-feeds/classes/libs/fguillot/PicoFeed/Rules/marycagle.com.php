<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'body' => array(
                '//img[@id="cc-comic"]',
                '//div[@class="cc-newsbody"]'
            ),
            'strip' => array(),
            'test_url' => 'http://www.marycagle.com/letsspeakenglish/74-grim-reality/',
        )
    ),
);
