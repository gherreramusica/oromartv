<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.themerepublic.net/2015/04/david-lopez-pitoko.html?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+blogspot%2FDngUJ+%28Theme+Republic%29&utm_content=FeedBurner',
            'body' => array('//*[@class="post-body"]'),
            'strip' => array(),
        )
    )
);