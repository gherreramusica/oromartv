<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.smashingmagazine.com/2015/04/17/using-sketch-for-responsive-web-design-case-study/',
            'body' => array('//article[contains(@class,"post")]/p'),
            'strip' => array(),
        )
    )
);