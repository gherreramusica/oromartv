<?php

namespace PicoFeed\Parser;

/**
 * MalformedXmlException Exception
 *
 * @author  Frederic Guillot
 * @package Parser
 */
class MalformedXmlException extends ParserException
{
}