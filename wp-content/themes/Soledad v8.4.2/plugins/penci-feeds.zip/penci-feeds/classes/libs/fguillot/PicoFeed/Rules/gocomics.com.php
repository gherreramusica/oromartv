<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.gocomics.com/pearlsbeforeswine/2015/05/30',
            'body' => array(
                '//div[1]/p[1]/a[1]/img',
            ),
            'strip' => array(),
        )
    )
);
