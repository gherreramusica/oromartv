<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://loldwell.com/?comic=food-math-101',
            'body' => array('//*[@id="comic"]'),
            'strip' => array(),
        )
    )
);