<?php

namespace PicoFeed\Client;

/**
 * InvalidCertificateException Exception
 *
 * @author  Frederic Guillot
 * @package Client
 */
class InvalidCertificateException extends ClientException
{
}
