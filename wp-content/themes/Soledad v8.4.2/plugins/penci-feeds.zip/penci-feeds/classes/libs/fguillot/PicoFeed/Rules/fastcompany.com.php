<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.fastcompany.com/3026712/fast-feed/elon-musk-an-apple-tesla-merger-is-very-unlikely',
            'body' => array(
                '//article[contains(@class, "body prose")]',
            ),
            'strip' => array(
            )
        )
    )
);
