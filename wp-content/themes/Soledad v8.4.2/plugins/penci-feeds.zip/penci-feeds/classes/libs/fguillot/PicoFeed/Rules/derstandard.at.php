<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://derstandard.at/2000010267354/The-Witcher-3-Hohe-Hardware-Anforderungen-fuer-PC-Spieler?ref=rss',
            'body' => array(
                '//div[@class="copytext"]',
                '//ul[@id="media-list"]',
            ),
            'strip' => array(
            ),
        )
    )
);
