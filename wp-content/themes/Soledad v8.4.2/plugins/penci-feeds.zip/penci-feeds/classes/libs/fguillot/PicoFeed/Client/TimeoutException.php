<?php

namespace PicoFeed\Client;

/**
 * TimeoutException Exception
 *
 * @author  Frederic Guillot
 * @package Client
 */
class TimeoutException extends ClientException
{
}
