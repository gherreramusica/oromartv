<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://stupidfox.net/134-sleepy-time',
            'body' => array(
                '//div[@class="comicmid"]/center/a/img',
                '//div[@class="stand_high"]'
            ),
            'strip' => array(),
        )
    )
);