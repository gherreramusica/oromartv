<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://consomac.fr/news-2430-l-iphone-6-toujours-un-secret-bien-garde.html',
            'body' => array(
                '//div[contains(@id, "newscontent")]',
            ),
            'strip' => array(
            ),
        )
    )
);