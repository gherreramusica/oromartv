<?php

namespace PicoFeed\Client;

/**
 * InvalidUrlException Exception
 *
 * @author  Frederic Guillot
 * @package Client
 */
class InvalidUrlException extends ClientException
{
}
