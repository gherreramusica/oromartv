<?php

namespace PicoFeed\Parser;

/**
 * RSS 0.91 Parser
 *
 * @author  Frederic Guillot
 * @package Parser
 */
class Rss91 extends Rss20
{
}
