<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.lfg.co/page/871/?utm_source=feedburner&utm_medium=feed&utm_campaign=Feed%3A+LookingForGroup+%28Looking+For+Group%29&utm_content=FeedBurner',
            'body' => array(
                '//*[@id="comic"]/img | //*[@class="content"]'
            ),
            'strip' => array(),
        )
    )
);

