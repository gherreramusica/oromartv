<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'https://www.scrumalliance.org/community/articles/2015/march/an-introduction-to-agile-project-intake?feed=articles',
            'body' => array(
                '//div[@class="article_content"]',
            ),
            'strip' => array()
        )
    )
);
