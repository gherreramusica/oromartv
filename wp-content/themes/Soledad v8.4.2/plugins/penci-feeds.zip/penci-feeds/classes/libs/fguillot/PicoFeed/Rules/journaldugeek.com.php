<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www./2014/05/20/le-playstation-now-arrive-en-beta-fermee-aux-etats-unis/',
            'body' => array(
                '//div[@class="post-content"]',
            )
        )
    )
);