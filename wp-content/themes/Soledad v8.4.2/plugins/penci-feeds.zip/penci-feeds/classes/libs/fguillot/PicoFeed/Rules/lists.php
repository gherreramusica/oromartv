<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://lists.freebsd.org/pipermail/freebsd-announce/2013-September/001504.html',
            'body' => array(
                '//pre',
            ),
            'strip' => array(
            )
        )
    )
);
