<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://buttersafe.com/2015/04/21/the-incredible-flexible-man/',
            'body' => array(
                '//div[@id="comic"]',
                '//div[@class="post-comic"]',
            ),
            'strip' => array()
        )
    )
);
