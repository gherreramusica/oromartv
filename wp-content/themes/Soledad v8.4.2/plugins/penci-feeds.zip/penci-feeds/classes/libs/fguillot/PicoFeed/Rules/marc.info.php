<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://marc.info/?l=openbsd-misc&m=141987113202061&w=2',
            'body' => array(
                '//pre',
            ),
            'strip' => array(
            ),
        )
    )
);
