<?php
return array(
    'grabber' => array(
        '%.*%' => array(
            'test_url' => 'http://www.igen.fr/ailleurs/2014/05/nvidia-va-delaisser-les-smartphones-grand-public-86031',
            'body' => array(
                '//div[contains(@class, "field-name-body")]'
            ),
            'strip' => array(
            ),
        )
    )
);