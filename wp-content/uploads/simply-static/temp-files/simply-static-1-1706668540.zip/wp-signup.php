<!DOCTYPE html>
<html>
	<head>
		<title>Redirigiendo...</title>
		<meta http-equiv="refresh" content="0;url=/wp-login.php?action=register">
	</head>
	<body>
		<script type="text/javascript">
			window.location = "/wp-login.php?action=register";
		</script>

		<p>Estás siendo redirigido a <a href="/wp-login.php?action=register">/wp-login.php?action=register</a></p>
	</body>
</html>
